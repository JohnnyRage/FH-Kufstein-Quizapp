package fh_ku.testing;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;

    int counter = 0;

    String zeile1 = null;
    String zeile2 = null;
    String zeile3 = null;
    String zeile4 = null;
    String zeile5 = null;




    TextView text;
    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.textView2);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.button5);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);

        /////////////////////////////////////////////////////////

        // File Writer

        File file = new File(context.getFilesDir(),"questions.txt");

        FileWriter fw = null;

        try {
            fw = new FileWriter(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        BufferedWriter bw = new BufferedWriter(fw);
    try
    {

            bw.write("Was ist die Haupstadt von Belgien?");
            bw.newLine();
            bw.write("Wie lang ist der Äquator?");
            bw.newLine();
            bw.write("Wie heißt der Präsident der USA? (neugewählt)");
            bw.newLine();
            bw.write("Wo war die letzte Fußball WM?");
            bw.newLine();
            bw.write("Was ist schief und ist in Pisa?");
            bw.close();
    }
    catch (IOException e)
    {
        e.printStackTrace();
    }

        /////////////////////////////////////////////////////////

        //File Reader

        FileReader fr = null;

        try {
            fr = new FileReader(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        BufferedReader br = new BufferedReader(fr);

        try {


            zeile1 = br.readLine();

            zeile2 = br.readLine();

            zeile3 = br.readLine();

            zeile4 = br.readLine();

            zeile5 = br.readLine();
            br.close();



        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

        /////////////////////////////////////////////////////////

        // Button färben

        /////////////////////////////////////////////////////////

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                btn5.setText("Weiter");

                for(int i=0;i<4;i++)
                {

                    switch(counter)
                    {
                        case 0: text.setText(zeile1);
                            btn1.setText("Kufstein");
                            btn2.setText("Istanbul");
                            btn3.setText("Brüssel");
                            btn4.setText("Rom");

                            break;


                        case 1: text.setText(zeile2);

                            btn1.setText("500");
                            btn2.setText("10");
                            btn3.setText("40000");
                            btn4.setText("2");
                            break;

                        case 2: text.setText(zeile3);
                            btn1.setText("Arnold Schwarzenegger");
                            btn2.setText("Hillary Clinton");
                            btn3.setText("Osama Bin Laden");
                            btn4.setText("Donald Trump");
                            break;

                        case 3: text.setText(zeile4);
                            btn1.setText("Brasilien");
                            btn2.setText("Paris");
                            btn3.setText("Österreich");
                            btn4.setText("Uganda");
                            break;

                        case 4: text.setText(zeile5);
                            btn1.setText("Eifelturm");
                            btn2.setText("Triumphbogen");
                            btn3.setText("Trumptower");
                            btn4.setText("Schiefer Turm");
                            break;



                    }  i++;
                }

                counter++;

                if(counter >=2)
                {
                    btn1.setBackgroundColor(Color.LTGRAY);
                    btn2.setBackgroundColor(Color.LTGRAY);
                    btn3.setBackgroundColor(Color.LTGRAY);
                    btn4.setBackgroundColor(Color.LTGRAY);
                }


            }
        });

    }


    @Override
    public void onClick(View v) {

        if(counter==1)
        {



       switch(v.getId())
        {


            case R.id.btn1:
                btn1.setBackgroundColor(Color.RED);
                btn2.setBackgroundColor(Color.RED);
                btn3.setBackgroundColor(Color.GREEN);
                btn4.setBackgroundColor(Color.RED);
                break;

            case R.id.btn2:
                btn1.setBackgroundColor(Color.RED);
                btn2.setBackgroundColor(Color.RED);
                btn3.setBackgroundColor(Color.GREEN);
                btn4.setBackgroundColor(Color.RED);
                break;

            case R.id.btn3:
                btn1.setBackgroundColor(Color.RED);
                btn2.setBackgroundColor(Color.RED);
                btn3.setBackgroundColor(Color.GREEN);
                btn4.setBackgroundColor(Color.RED);
                break;

            case R.id.btn4:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.GREEN);
                    btn4.setBackgroundColor(Color.RED);
                    break;

        }
    }

        else if(counter ==2)
        {
            switch(v.getId())
            {


                case R.id.btn1:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.GREEN);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn2:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.GREEN);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn3:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.GREEN);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn4:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.GREEN);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

            }
        }
        else if(counter ==3)
        {
            switch(v.getId())
            {


                case R.id.btn1:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn2:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn3:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn4:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

            }
        }

        else if(counter ==4)
        {
            switch(v.getId())
            {


                case R.id.btn1:
                    btn1.setBackgroundColor(Color.GREEN);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn2:
                    btn1.setBackgroundColor(Color.GREEN);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn3:
                    btn1.setBackgroundColor(Color.GREEN);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

                case R.id.btn4:
                    btn1.setBackgroundColor(Color.GREEN);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.RED);
                    break;

            }
        }
        else if(counter ==5)
        {
            switch(v.getId())
            {


                case R.id.btn1:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn2:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn3:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

                case R.id.btn4:
                    btn1.setBackgroundColor(Color.RED);
                    btn2.setBackgroundColor(Color.RED);
                    btn3.setBackgroundColor(Color.RED);
                    btn4.setBackgroundColor(Color.GREEN);
                    break;

            }
        }

    }
}








