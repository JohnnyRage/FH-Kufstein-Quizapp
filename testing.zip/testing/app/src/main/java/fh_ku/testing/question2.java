package fh_ku.testing;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

/**
 * Created by Johannes Larcher on 19.12.2016.
 */

public class question2 extends AppCompatActivity {

    TextView txt1 = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question2);

        Bundle b = getIntent().getExtras();
       String question = b.getString("question");

        txt1 = (TextView)findViewById(R.id.txt1);

        txt1.setText(question);



    }

}


